package ejercicio1.app;

import ejercicio1.vista.VentanaNotas;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaNotas().setVisible(true));
    }
}
