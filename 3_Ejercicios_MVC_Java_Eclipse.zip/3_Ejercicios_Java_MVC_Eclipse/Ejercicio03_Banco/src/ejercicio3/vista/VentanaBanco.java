package ejercicio3.vista;

import ejercicio3.controlador.CuentaControlador;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.IOException;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaBanco extends JFrame {
    private final CuentaControlador controlador;
    private final JLabel saldo = new JLabel();
    private final JTextField monto = new JTextField();
    private final JTextArea movimientos = new JTextArea(10, 35);

    public VentanaBanco(CuentaControlador controlador) {
        super("Ejercicio 3 - Cuenta bancaria");
        this.controlador = controlador;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(540, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        JPanel formulario = new JPanel(new GridLayout(3, 2, 8, 8));
        formulario.add(new JLabel("Saldo actual:")); formulario.add(saldo);
        formulario.add(new JLabel("Monto ($):")); formulario.add(monto);
        JButton deposito = new JButton("Depositar");
        JButton retiro = new JButton("Retirar");
        formulario.add(deposito); formulario.add(retiro);
        add(formulario, BorderLayout.NORTH);
        movimientos.setEditable(false);
        add(new JScrollPane(movimientos), BorderLayout.CENTER);
        deposito.addActionListener(e -> operar("DEPOSITO"));
        retiro.addActionListener(e -> operar("RETIRO"));
        actualizar();
    }

    private void operar(String tipo) {
        try {
            JOptionPane.showMessageDialog(this, controlador.operar(tipo, monto.getText()));
            monto.setText("");
            actualizar();
        } catch (IllegalArgumentException | IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizar() {
        saldo.setText(String.format(Locale.US, "$%.2f", controlador.obtenerSaldo()));
        try {
            movimientos.setText(controlador.verMovimientos());
        } catch (IOException ex) {
            movimientos.setText("No se pudo leer el historial: " + ex.getMessage());
        }
    }
}
