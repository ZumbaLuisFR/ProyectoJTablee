package ejercicio3.modelo;

public class Cuenta {
    private double saldo;

    public Cuenta(double saldoInicial) { saldo = saldoInicial; }
    public double getSaldo() { return saldo; }
    public void establecerSaldo(double nuevoSaldo) { saldo = nuevoSaldo; }
}
