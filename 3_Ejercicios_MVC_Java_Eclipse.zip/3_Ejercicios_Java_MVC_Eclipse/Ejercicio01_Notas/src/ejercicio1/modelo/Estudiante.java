package ejercicio1.modelo;

public class Estudiante {
    private final String nombre;
    private final double nota1;
    private final double nota2;

    public Estudiante(String nombre, double nota1, double nota2) {
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
    }

    public String getNombre() { return nombre; }
    public double getNota1() { return nota1; }
    public double getNota2() { return nota2; }
    public double getPromedio() { return (nota1 + nota2) / 2; }
    public String getEstado() { return getPromedio() >= 7 ? "APROBADO" : "REPROBADO"; }
}
