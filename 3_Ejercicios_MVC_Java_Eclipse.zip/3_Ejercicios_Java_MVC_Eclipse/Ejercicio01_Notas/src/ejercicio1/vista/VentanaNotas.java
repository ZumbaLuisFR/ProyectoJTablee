package ejercicio1.vista;

import ejercicio1.controlador.EstudianteControlador;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaNotas extends JFrame {
    private final EstudianteControlador controlador = new EstudianteControlador();
    private final JTextField nombre = new JTextField();
    private final JTextField nota1 = new JTextField();
    private final JTextField nota2 = new JTextField();
    private final JTextArea resultado = new JTextArea(10, 35);

    public VentanaNotas() {
        super("Ejercicio 1 - Registro de notas");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 340);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        JPanel formulario = new JPanel(new GridLayout(4, 2, 8, 8));
        formulario.add(new JLabel("Nombre:")); formulario.add(nombre);
        formulario.add(new JLabel("Nota 1 (0 a 10):")); formulario.add(nota1);
        formulario.add(new JLabel("Nota 2 (0 a 10):")); formulario.add(nota2);
        JButton guardar = new JButton("Registrar y calcular");
        JButton ver = new JButton("Ver registros");
        formulario.add(guardar); formulario.add(ver);
        add(formulario, BorderLayout.NORTH);
        resultado.setEditable(false);
        add(new JScrollPane(resultado), BorderLayout.CENTER);
        guardar.addActionListener(e -> registrar());
        ver.addActionListener(e -> mostrarRegistros());
        mostrarRegistros();
    }

    private void registrar() {
        try {
            String mensaje = controlador.registrar(nombre.getText(), nota1.getText(), nota2.getText());
            JOptionPane.showMessageDialog(this, mensaje);
            nombre.setText(""); nota1.setText(""); nota2.setText("");
            mostrarRegistros();
        } catch (IllegalArgumentException | IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarRegistros() {
        try {
            resultado.setText(controlador.verRegistros());
        } catch (IOException ex) {
            resultado.setText("No se pudieron leer los registros: " + ex.getMessage());
        }
    }
}
