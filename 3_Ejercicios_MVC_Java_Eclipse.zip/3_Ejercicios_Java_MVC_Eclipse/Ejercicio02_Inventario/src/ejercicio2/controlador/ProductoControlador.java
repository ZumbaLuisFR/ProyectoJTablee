package ejercicio2.controlador;

import ejercicio2.modelo.Producto;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

public class ProductoControlador {
    private final Path archivo = Paths.get("inventario.txt");
    private final Map<String, Producto> productos = new LinkedHashMap<>();

    public ProductoControlador() throws IOException {
        if (Files.exists(archivo)) {
            for (String linea : Files.readAllLines(archivo, StandardCharsets.UTF_8)) {
                String[] datos = linea.split(";", -1);
                if (datos.length != 3) continue;
                try {
                    String nombre = datos[0];
                    int cantidad = Integer.parseInt(datos[1]);
                    double precio = Double.parseDouble(datos[2]);
                    if (nombre.isEmpty() || cantidad <= 0 || !Double.isFinite(precio) || precio <= 0) continue;
                    Producto p = new Producto(nombre, cantidad, precio);
                    productos.put(nombre.toLowerCase(Locale.ROOT), p);
                } catch (NumberFormatException ex) {
                    continue;
                }
            }
        }
    }

    public String agregar(String nombre, String cantidadTexto, String precioTexto) throws IOException {
        nombre = nombre.trim();
        if (nombre.length() < 2 || nombre.contains(";") || nombre.contains("\n")) {
            throw new IllegalArgumentException("Ingrese un nombre de producto válido.");
        }
        int cantidad;
        double precio;
        try {
            cantidad = Integer.parseInt(cantidadTexto.trim());
            precio = Double.parseDouble(precioTexto.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Cantidad y precio deben ser numéricos.");
        }
        if (cantidad <= 0 || !Double.isFinite(precio) || precio <= 0) {
            throw new IllegalArgumentException("La cantidad y el precio deben ser mayores que cero.");
        }
        String clave = nombre.toLowerCase(Locale.ROOT);
        if (productos.containsKey(clave)) {
            throw new IllegalArgumentException("Ese producto ya está registrado.");
        }
        Producto p = new Producto(nombre, cantidad, precio);
        String linea = String.format(Locale.US, "%s;%d;%.2f", p.getNombre(), p.getCantidad(), p.getPrecio());
        Files.write(archivo, (linea + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        productos.put(clave, p);
        return String.format(Locale.US, "Registrado: %s. Subtotal: $%.2f", nombre, p.getSubtotal());
    }

    public String listar() {
        if (productos.isEmpty()) return "Sin productos registrados.";
        StringBuilder sb = new StringBuilder();
        for (Producto p : productos.values()) {
            sb.append(String.format(Locale.US, "%s | %d x $%.2f = $%.2f%n",
                    p.getNombre(), p.getCantidad(), p.getPrecio(), p.getSubtotal()));
        }
        sb.append(String.format(Locale.US, "%nTOTAL DEL INVENTARIO: $%.2f", total()));
        return sb.toString();
    }

    public double total() {
        double suma = 0;
        for (Producto p : productos.values()) suma += p.getSubtotal();
        return suma;
    }
}
