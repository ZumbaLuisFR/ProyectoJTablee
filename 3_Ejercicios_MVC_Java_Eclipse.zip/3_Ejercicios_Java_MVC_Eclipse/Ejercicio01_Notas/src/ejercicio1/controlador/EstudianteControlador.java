package ejercicio1.controlador;

import ejercicio1.modelo.Estudiante;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Locale;

public class EstudianteControlador {
    private final Path archivo = Paths.get("estudiantes.txt");

    public String registrar(String nombre, String n1, String n2) throws IOException {
        nombre = nombre.trim();
        if (nombre.length() < 2 || nombre.contains(";") || nombre.contains("\n")) {
            throw new IllegalArgumentException("Ingrese un nombre válido de al menos 2 letras.");
        }
        double nota1 = leerNota(n1);
        double nota2 = leerNota(n2);
        Estudiante e = new Estudiante(nombre, nota1, nota2);
        String linea = String.format(Locale.US, "%s;%.2f;%.2f;%.2f;%s", e.getNombre(),
                e.getNota1(), e.getNota2(), e.getPromedio(), e.getEstado());
        Files.write(archivo, (linea + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        return String.format(Locale.US, "%s | Promedio: %.2f | %s", nombre,
                e.getPromedio(), e.getEstado());
    }

    private double leerNota(String texto) {
        try {
            double valor = Double.parseDouble(texto.trim().replace(',', '.'));
            if (!Double.isFinite(valor) || valor < 0 || valor > 10) {
                throw new NumberFormatException();
            }
            return valor;
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Las notas deben ser números entre 0 y 10.");
        }
    }

    public String verRegistros() throws IOException {
        if (!Files.exists(archivo)) return "Todavía no hay estudiantes registrados.";
        StringBuilder salida = new StringBuilder();
        for (String linea : Files.readAllLines(archivo, StandardCharsets.UTF_8)) {
            String[] d = linea.split(";", -1);
            if (d.length == 5) {
                salida.append(d[0]).append(" | Promedio: ").append(d[3])
                      .append(" | ").append(d[4]).append('\n');
            }
        }
        return salida.length() == 0 ? "Todavía no hay estudiantes registrados." : salida.toString();
    }
}
