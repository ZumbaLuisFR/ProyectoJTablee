package ejercicio3.app;

import ejercicio3.controlador.CuentaControlador;
import ejercicio3.vista.VentanaBanco;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new VentanaBanco(new CuentaControlador()).setVisible(true);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error al leer movimientos.txt: " + ex.getMessage());
            }
        });
    }
}
