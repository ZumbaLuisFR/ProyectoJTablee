package ejercicio2.app;

import ejercicio2.controlador.ProductoControlador;
import ejercicio2.vista.VentanaInventario;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                new VentanaInventario(new ProductoControlador()).setVisible(true);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Error al leer inventario.txt: " + ex.getMessage());
            }
        });
    }
}
