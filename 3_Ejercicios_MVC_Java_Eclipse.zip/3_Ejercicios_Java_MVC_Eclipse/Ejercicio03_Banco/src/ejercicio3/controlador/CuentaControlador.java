package ejercicio3.controlador;

import ejercicio3.modelo.Cuenta;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.Locale;

public class CuentaControlador {
    private final Path archivo = Paths.get("movimientos.txt");
    private final Cuenta cuenta = new Cuenta(100.00);

    public CuentaControlador() throws IOException {
        if (!Files.exists(archivo)) return;
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        for (String linea : lineas) {
            String[] datos = linea.split(";", -1);
            if (datos.length != 3) continue;
            try {
                double saldo = Double.parseDouble(datos[2]);
                if (Double.isFinite(saldo) && saldo >= 0) cuenta.establecerSaldo(saldo);
            } catch (NumberFormatException ex) {
                continue;
            }
        }
    }

    public String operar(String tipo, String montoTexto) throws IOException {
        double monto;
        try {
            monto = Double.parseDouble(montoTexto.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Ingrese un monto numérico válido.");
        }
        if (!Double.isFinite(monto) || monto <= 0) {
            throw new IllegalArgumentException("El monto debe ser mayor que cero.");
        }
        if (!tipo.equals("DEPOSITO") && !tipo.equals("RETIRO")) {
            throw new IllegalArgumentException("Operación no reconocida.");
        }
        if (tipo.equals("RETIRO") && monto > cuenta.getSaldo()) {
            throw new IllegalArgumentException("Saldo insuficiente.");
        }
        double nuevoSaldo = tipo.equals("DEPOSITO") ? cuenta.getSaldo() + monto : cuenta.getSaldo() - monto;
        if (!Double.isFinite(nuevoSaldo)) throw new IllegalArgumentException("Monto demasiado grande.");
        String linea = String.format(Locale.US, "%s;%.2f;%.2f", tipo, monto, nuevoSaldo);
        Files.write(archivo, (linea + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        cuenta.establecerSaldo(nuevoSaldo);
        return String.format(Locale.US, "%s de $%.2f realizado. Saldo: $%.2f", tipo, monto, nuevoSaldo);
    }

    public double obtenerSaldo() { return cuenta.getSaldo(); }

    public String verMovimientos() throws IOException {
        if (!Files.exists(archivo)) return "Aún no hay movimientos.";
        StringBuilder sb = new StringBuilder();
        for (String linea : Files.readAllLines(archivo, StandardCharsets.UTF_8)) {
            String[] d = linea.split(";", -1);
            if (d.length == 3) {
                sb.append(d[0]).append(" | $ ").append(d[1])
                  .append(" | Saldo: $ ").append(d[2]).append('\n');
            }
        }
        return sb.length() == 0 ? "Aún no hay movimientos." : sb.toString();
    }
}
