package ejercicio2.vista;

import ejercicio2.controlador.ProductoControlador;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VentanaInventario extends JFrame {
    private final ProductoControlador controlador;
    private final JTextField nombre = new JTextField();
    private final JTextField cantidad = new JTextField();
    private final JTextField precio = new JTextField();
    private final JTextArea resultado = new JTextArea(10, 35);

    public VentanaInventario(ProductoControlador controlador) {
        super("Ejercicio 2 - Inventario de productos");
        this.controlador = controlador;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(550, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        JPanel formulario = new JPanel(new GridLayout(4, 2, 8, 8));
        formulario.add(new JLabel("Producto:")); formulario.add(nombre);
        formulario.add(new JLabel("Cantidad:")); formulario.add(cantidad);
        formulario.add(new JLabel("Precio unitario ($):")); formulario.add(precio);
        JButton agregar = new JButton("Agregar producto");
        JButton ver = new JButton("Actualizar listado");
        formulario.add(agregar); formulario.add(ver);
        add(formulario, BorderLayout.NORTH);
        resultado.setEditable(false);
        add(new JScrollPane(resultado), BorderLayout.CENTER);
        agregar.addActionListener(e -> agregarProducto());
        ver.addActionListener(e -> actualizar());
        actualizar();
    }

    private void agregarProducto() {
        try {
            JOptionPane.showMessageDialog(this,
                    controlador.agregar(nombre.getText(), cantidad.getText(), precio.getText()));
            nombre.setText(""); cantidad.setText(""); precio.setText("");
            actualizar();
        } catch (IllegalArgumentException | IOException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validación", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizar() { resultado.setText(controlador.listar()); }
}
